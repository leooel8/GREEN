Bonjour, 
La soumission que voici ne fonctionne pas sur codalab. 
Nous n'en avons pas compris la raison, étant donné que, en exécutant model.py sur un terminal, cela fonctionne très bien.
Nous vous invitons donc à le faire afin de visualiser nos résultats.
Merci d'avance,
L'Equipe GREEN

PS: il est normal de retrouver les fichiers 'public_data', 'ingestion_program' et 'scoring_program' dans cette soumission, car model.py en a besoin pour certaines de ses fonctions et notamment
dans le 'main'.

